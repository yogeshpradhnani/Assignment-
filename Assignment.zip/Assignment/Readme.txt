Step 1: Set Up the Environment
install  with pip
pip install fastapi uvicorn sqlalchemy pymysql
Step 2: Create the MySQL Table
Assuming you have a MySQL server running, create the user table:

 Step 2 sql
CREATE DATABASE fastapi_db;
USE fastapi_db;

CREATE TABLE user (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    mail_id VARCHAR(100),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
Step 3: Create the FastAPI Application


4.     Create a Virtual Environment:

python -m venv env


5. Running the Application

uvicorn main:app --reload